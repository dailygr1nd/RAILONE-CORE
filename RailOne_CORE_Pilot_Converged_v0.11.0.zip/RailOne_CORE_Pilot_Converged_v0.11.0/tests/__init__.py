"""RailOne pilot baseline tests."""
